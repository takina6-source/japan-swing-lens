# 日本株 Swing Lens

日本株を6つの著名なスイング／モメンタム手法で横断分析し、候補、判定根拠、
条件付きエントリー帯、損切り・利確目安を表示するローカルアプリです。
J-Quantsの有料契約なしで運用できる構成を標準にしています。

## スマホ・クラウド版

`public/dashboard` に、Macを起動しなくても閲覧できる軽量Web版を実装しています。
生の株価DBは公開せず、全銘柄ランキングと銘柄別の最新分析だけを書き出します。

- スマホ優先レイアウト
- 銘柄コード・会社名検索
- 状態フィルター
- エントリー、損切り、1R・2R利確
- 手法別判定と全条件の内訳
- 直近180日のチャート
- ホーム画面追加対応
- Strategy固有Structure PivotとPivot Fidelity
- 5手法Breakout Consensus（Connorsは別枠）
- Coverage / Confidence
- Signal Snapshot・1/5/10/20営業日後の自動追跡
- ChatGPTレビュー用CSV / JSON
- 20日平均売買代金の段階評価・低流動性警告・Trading Value Ratio

`.github/workflows/update-dashboard.yml` は平日19:00（日本時間）に分析を実行し、
成功した場合だけGitHub Pagesを更新します。失敗した日は前回公開版がそのまま残ります。
手動実行にも対応しています。

### GitHub Pagesを有効にする

1. このフォルダをGitHubリポジトリへ登録する
2. GitHubの **Settings → Pages → Source** で **GitHub Actions** を選ぶ
3. **Actions → Update Swing Lens → Run workflow** を一度実行する
4. 表示されたPages URLをスマホへ登録する

EDINETを使う場合だけ、GitHubの **Settings → Secrets and variables → Actions** に
`EDINET_API_KEY` を登録します。キーはWebサイトや公開データには書き出されません。

公開データを手元で再生成する場合は次を実行します。

```bash
.venv/bin/python scripts/export_web.py
```

### ChatGPTへ検証を依頼する

最初に次のURLを提示してください。

`https://takina6-source.github.io/japan-swing-lens/validation/index.json`

ChatGPTは件数と期間を確認後、目的に応じて `signals.csv`、`performance.csv`、
`controls.csv`、`control_performance.csv`、`summary.csv` を参照できます。Market、固定Random、
条件の近い非Signal銘柄に対するExcess Returnも比較できます。画面下部から直接ダウンロードできます。
詳細なschemaと判定仕様は [`docs/VALIDATION.md`](docs/VALIDATION.md) を参照してください。

### Experimental Strategies（並走検証）

Coreとは独立したResearch Layerとして、Turtle / Donchian Breakout、Earnings Momentum、
Sector Relative Strengthの3手法を `2026-09-01` から記録します。ランキング一覧では
`Experimental x/3` だけを補助表示し、詳細画面で各手法のStateと根拠を確認できます。
Experimentalの結果はCore Consensus、Confluence、BREAKOUT判定、順位、Confidence、Coverageへ
一切加算しません。

Experimental Validationの入口は次の固定URLです。

`https://takina6-source.github.io/japan-swing-lens/experimental/index.json`

Signal、History、1/5/10/20営業日Performance、Random / Matched Control、Version別Summaryを
`/experimental/` 配下へ出力します。仕様、判定条件、無料データの制約は
[`docs/EXPERIMENTAL.md`](docs/EXPERIMENTAL.md) を参照してください。

### Research Layer（事前固定仮説の将来検証）

Coreの判定・ランキングを一切変更せず、既存の日足、Signal Snapshot、Validationを使って
H1〜H4を別系統で検証します。Registryと検証条件は2026-09-09に固定し、2026-09-10以降の
`LIVE_FORWARD + HOLDOUT`だけを正式確認に使います。過去再構築データは探索専用です。

Research exportの入口は次の固定URLです。

`https://takina6-source.github.io/japan-swing-lens/research/index.json`

3つのEntryモデル、Research専用Control、Checkpoint A/B、Family Close、Holm補正、
日足内順序が不明な`PATH_AMBIGUOUS`、処理時間・保存量を`/research/`配下へ出力します。

### Research進捗Viewer

公開サイト上部の「Research進捗」、または次の直接URLから開けます。

`https://takina6-source.github.io/japan-swing-lens/#research`

Routingは`#research`を使用し、通常URLは従来どおり銘柄ランキングを表示します。ブラウザの
戻る・進む、直接アクセス、再読込に対応します。Research JSONはResearch画面を開いたときだけ
読み込み、取得・描画エラーはResearch画面内に閉じ込めるため、Coreランキングは継続利用できます。

初期表示は「かんたん」で、日本語名と元のResearch用語、CheckpointのAND条件、データ用途、Entry
Model、日足診断を確認できます。「詳細」ではRegistry、途中統計、性能、保存量を表示します。値が
存在しない場合は0へ置き換えずN/Aまたは未計算と表示します。表示には以下の静的JSONだけを使います。

- `research/index.json`
- `research/hypotheses.json`
- `research/families.json`
- `research/checkpoints.json`
- `research/intraday_diagnostics.json`
- `research/storage_metrics.json`
- `research/performance_metrics.json`

画面契約のテストは`pytest -q tests/test_research_ui.py`、Research出力を含む統合テストは
`pytest -q tests/test_research_pipeline.py`、Core固定入力比較は
`python scripts/fixed_input_regression.py`で実行します。
詳細は [`docs/RESEARCH.md`](docs/RESEARCH.md) を参照してください。

## 起動方法

Finderで `start.command` をダブルクリックします。初回は環境準備と株価取得に数分かかることがあります。
ブラウザが自動で開いたら、左側を次のように設定してください。

1. 運用モード: **無料実用**
2. 分析範囲: 最初は **主要500+Growth**（約1,000銘柄）
3. 取得後に「今日のランキング」から候補を選ぶ

2回目以降はSQLiteの保存データに直近分だけを追加するため、初回より短時間になります。
更新をやり直したい場合は左側の「データを更新」を押します。

macOSが初回起動を止める場合は、Finderで `start.command` をControlクリックして「開く」を選びます。
同一LANのiPhoneからは、MacのIPアドレスと `:8501`（例 `http://192.168.1.20:8501`）へ
アクセスできます。利用中はMacとアプリを起動したままにしてください。

## 無料実用モードのデータ構成

| 用途 | データ源 | キー | 注意点 |
|---|---|---:|---|
| 上場銘柄・市場・業種 | JPX公式「東証上場銘柄一覧」 | 不要 | 月次更新 |
| 日足・出来高・TOPIX代理系列（1306 ETF） | Yahoo Finance / `yfinance` | 不要 | 非公式経路。仕様変更や一時失敗の可能性あり |
| 財務（売上・EPS・ROE等） | EDINET → J-Quants → Yahoo | EDINET/J-Quantsは無料キー・任意 | 年度単位で優先ソースを採用。Yahooは非公式補完 |
| 公式株価との照合 | J-Quants Free | 無料キー・任意 | 遅延データ。ランキング株価には不使用 |

株価の取得に失敗しても、保存済みデータがあれば分析を継続します。画面には最終株価日、取得率、
EDINET財務の保有銘柄数を表示します。財務がない条件は `×` にせず `N/A` として扱います。

## 無料キーの設定（任意）

日足テクニカル分析だけならキーなしで使えます。CAN SLIMなど財務条件も充実させる場合は、
本人がEDINETで無料APIキーを発行し、画面左の「無料EDINET財務を設定」に入力してください。
J-Quants Freeは「任意：J-Quants Free照合」から設定します。

年次EPSはEDINET標準タグ、EDINET拡張タグ、EDINETからの派生値、J-Quants、Yahooの順で
不足年度だけを補います。同じ年度に複数値がある場合は優先順位を固定し、10%超の差を
`DATA_CONFLICT` として残します。取得状態は銘柄詳細の「CAN SLIM A：年次EPS」で確認できます。
一括診断は `python scripts/diagnose_fundamentals.py --na-only`、1銘柄は末尾に4桁コードを指定します。

キーはこのMacの `.streamlit/secrets.toml` にだけ保存され、株価DBと同様にGit管理対象外です。
チャットへキーを貼り付けないでください。

## 無料版で有料版より弱い部分

- Yahoo日足は公式APIではなく、継続性・補正仕様・取得安定性を保証できません。
- EDINETは速報用ではないため、四半期決算直後の売上・EPS判定が遅れることがあります。
- 決算予定、機関投資家保有、詳細な業績予想などは欠損しやすく、該当条件は `N/A` です。
- 自動売買や証券会社への注文送信は行いません。

したがって、候補探索と売買計画の下調べには使えますが、注文前には適時開示、会社IR、
証券会社の現在値・決算予定を確認してください。

## 売買シナリオ

銘柄詳細に、条件付きエントリー帯、損切り目安、第1利確目安（1R）、基本利確目安（2R）、
伸長時の20%目安を表示します。Pivotから5%超離れた銘柄は追随警告を出し、
セットアップ未成立・過熱・失敗状態では価格を無理に提示せず「見送り」と表示します。

これらは教育・検証用の機械算出値であり、個人の資産、許容損失、税、注文状況、
決算リスクを反映した投資助言ではありません。

## 判定と保存

- **STRICT**: 原典条件を数値化できるもの
- **PRACTICAL**: 日足データ上での実用的な実装
- **PROXY**: 目視・独自データが必要な条件の機械判定近似

`data/momentum.db` に銘柄一覧、日足、財務、条件判定、シグナル、売買シナリオ、取得ログを保存します。
判定は `logic_version` とともに保存され、閾値は `config/thresholds.yaml` に分離されています。

## 開発者向け検証

```bash
python3 -m venv .venv
.venv/bin/pip install -e '.[jquants,test]'
.venv/bin/pytest
.venv/bin/python -m streamlit run app.py
```

実装条件と取得可否の詳細は [`docs/IMPLEMENTATION.md`](docs/IMPLEMENTATION.md) を参照してください。

## Earnings Momentum v2（四半期業績）

Experimental Earnings Momentumは`2026.09-exp-v2-quarterly-earnings`から、CAN SLIM Aの
年次EPSとは完全に分離した`quarterly_fundamentals`を使用します。J-Quantsの決算情報を優先し、
不足時はYahoo Quarterly Statementを自動補完します。Yahooは正確な公表日を保証できないため
`PROXY`とし、取得日より前の判定には利用しません。

EPS・売上・営業利益の前年同期比とEPS加速を四半期データから計算し、欠損はN/AのままCoverageへ
反映します。赤字から黒字への転換と極端な成長率は通常成長から分離します。この追加チェックは
Coreランキング、Core Consensus、Turtle、Sector RSには影響しません。

## データ品質表示（診断schema 2.0）

年次EPSのCoverageは、`complete_4y`（4期を完全取得）と
`usable_3y_plus`（CAN SLIM Aの判定に使える3期以上）を分離しています。
従来の`before_complete`／`after_complete`は3期以上も「complete」と表現していたため廃止しました。
取得成功を保証するように見える`*_fixable`も廃止し、未試行候補、試行対象、試行後も未解決の件数を
`source_retry_candidates`、`source_attempt_eligible`、`unresolved_after_attempts`で表します。

この変更は診断用JSON／CSVと画面ラベルだけを対象とし、Signal、Control、Performance、Core順位の
schemaと計算結果は変更しません。診断対象とランキング対象の件数が違う場合は、価格履歴不足などの
除外理由を`universe.excluded_from_ranking`へ集計します。

## 公平な財務更新・Yahoo EPS・固定入力CI

無料取得枠を一部の強い銘柄だけが占有しないよう、年次EPSと四半期財務は
`未試行 → 最終試行が古い → 取得済み期間が少ない → Momentum（同条件時のみ）`で更新します。
銘柄・データ種別・Sourceごとの結果は`data_update_attempts`へ保存し、一時失敗は1日、成功と
データ不足は7日、解析不能と設定不足は30日の再試行間隔を設けます。銘柄詳細では待機理由、
最終試行日、次回試行可能日を確認できます。

YahooのReported EPSは、イベント側に明示的な期末日があり、損益計算書の期末日と一意に一致し、
発表日が期末から120日以内の場合だけ補完します。表示順では割り当てません。`AMBIGUOUS`、
`UNMATCHED`、株式分割警告付きEPSは強い業績シグナルに使いません。

GitHub Actionsでは全pytestに加えて`python scripts/fixed_input_regression.py`を実行します。固定した
基準日、価格seed、財務入力、Control seedからCore/ExperimentalのSignal、History、Performance、
Control、Rankingを再生成し、`tests/fixtures/fixed_input/manifest.json`のSHA-256と比較します。
許可済み時刻項目以外が変わると公開処理は開始されません。仕様変更として基準値を更新する場合は、
差分を確認したうえで`python scripts/fixed_input_regression.py --update`を実行し、通常モードでもう一度
安定して一致することを確認してください。

## Investment Committee Integration

将来の「投資委員会」が複数の分析エンジンを比較できるよう、既存のSwing Lens評価を標準化した
静的JSONを公開します。このAdapterは生成済み結果を転記するだけで、Core/Experimentalの判定、
ランキング、画面には影響しません。

```json
{
  "schema_version": "1.0",
  "engine": "japan_swing_lens",
  "engine_version": "2026.09-v8-quarterly-earnings",
  "ticker": "9244",
  "evaluation_date": "2026-09-03",
  "generated_at": "2026-09-05T12:00:00+09:00",
  "verdict": "SETUP FORMING",
  "confidence": 0.8,
  "risk_level": null,
  "core": {"verdict": "SETUP FORMING", "rank": 1, "consensus": {}, "signals": {}},
  "experimental": {"alignment": null, "combination": null, "affects_core_ranking": false, "signals": {}},
  "signals": {"core": {}, "liquidity": {"status": "HIGH"}, "experimental": {}},
  "metrics": {},
  "source_status": {"price": {"status": "ok"}, "fundamentals": {"status": "partial"}, "earnings": {"status": "missing"}, "update_diagnostics": {}}
}
```

入口は[manifest](https://takina6-source.github.io/japan-swing-lens/committee/manifest.json)、
[ranking](https://takina6-source.github.io/japan-swing-lens/committee/ranking.json)、
[JSON Schema](https://takina6-source.github.io/japan-swing-lens/committee/schema.json)です。
`ticker`は`.T`なしのJPXコード文字列、`evaluation_date`は市場データの評価基準日でありJSON生成日時の
`generated_at`とは別です。`engine_version`は既存の`logic_version`、形式は`schema_version`で識別します。
将来のFundamental Lensも同じ識別子・日付・欠損規約のJSONを独立して公開し、Committeeだけが両者を
読み込む疎結合構成を予定しています。
キーの意味、欠損、履歴、Fundamental Lensとの整合条件は
[`docs/investment_committee_interface.md`](docs/investment_committee_interface.md)を参照してください。

## Morning Brief Phase 1（Core説明用JSON）

生成済みCore snapshot/detailだけを読むAdapterを追加しました。
`python scripts/export_briefing.py`で上位20件を`public/dashboard/briefing/latest.json`へ出力します。
`--limit 0`で全候補、`--output`で出力先を指定できます。価格取得・DB接続・再分析・LLM呼出しはありません。
順位、6手法の既存条件、Pivot/参考価格、品質・N/A理由を保持します。単独変換時はconfig対応を推定せず、versionを未確認にします。
workflowはCore Export成功直後に`--same-run-config`で接続します。履歴保存やUI追加は行いません。
[利用説明と制約](docs/MORNING_BRIEF.md)、[JSON Schema](schemas/morning_brief.schema.json)、
[9月3日基準の保存入力による出力例](docs/examples/morning-brief/latest.json)を参照してください。
